module.exports = {
    title: 'kou',
    description: '技术文档/个人博客',
    head: [
        ['link', { rel: 'icon', href: '/user.jpg' }]
    ],
    plugins: [
        ['flexsearch']
    ],
    markdown: {
        lineNumbers: true
    },
    // 导航栏链接
    themeConfig: {
        logo: '/images/logo.png',
        nav: [
            {
                text: '首页',
                link: '/'
            },
            {
                text: '前端',
                link: '/front/'
            },
            {
                text: '后端',
                link: '/java/'
            },
            {
                text: '微服务',
                link: '/cloud/'
            },
            {
                text: '跨平台',
                link: '/flutter/'
            },
            {
                text: '运维',
                link: '/devops/'
            },
            {
                text: '面试题',
                link: '/interview/'
            },

            {
                text: 'Yapi',
                link: 'http://yapi.heyige.cn/'
            },
            {
                text: '在线工具',
                ariaLabel: '使用工具',
                items: [
                    {
                        text: 'Maven中央仓库',
                        link: 'https://mvnrepository.com/'
                    },
                    {
                        text: 'JSON解析',
                        link: 'http://www.jsons.cn/'
                    },
                    {
                        text: 'PDFBox',
                        link: 'https://pdfbox.apache.org/'
                    },
                    {
                        text: 'NPM镜像站',
                        link: 'https://npmmirror.com/'
                    },
                    {
                        text: 'GitHub加速',
                        link: 'https://ghproxy.com/'
                    },
                    {
                        text: 'BootCDN',
                        link: 'https://www.bootcdn.cn/'
                    },
                    {
                        text: 'DaoCloud',
                        link: 'https://hub.daocloud.io/'
                    },
                    {
                        text: 'Redis命令',
                        link: 'http://redisdoc.com/index.html'
                    },
                    {
                        text: 'JetBrain激活',
                        link: 'https://3.jetbra.in/'
                    },
                    {
                        text: 'Google翻译',
                        link: 'https://translate.google.cn/'
                    },
                    {
                        text: '正则在线工具',
                        link: 'https://c.runoob.com/front-end/854/'
                    },
                    {
                        text: 'Google开发者',
                        link: 'https://developers.google.cn/'
                    }
                ]
            }
        ],
        lastUpdated: '最近更新',
        sidebar: {
            '/front/': [
                '',
                'html',
                'HtmlNote',
                'CSS',
                'js',
                'JsNote',
                'jquery',
                'JqNote',
                'AJAX',
                'bootstrap',
                'es6',
                'vue',
                'world'
            ],
            '/java/': [
                '',
                'exam',
                'MySQL',
                'MySQLNote',
                'MySQLPrac',
                'jdbc',
                'jdbc2',
                'servlet',
                'jsp',
                'mybatis',
                'spring',
                'springmvc',
                'springboot',
                'SpringJPA',
                'starter',
                'SpringSecurity',
                'SpringSecurity-JWT',
                'stream',
                'thread',
                'thread2',
                'Lock'
            ],
            '/cloud/': [
                '',
                'Yapi',
                'Jmeter',
                'Arthas',
                'ElasticSearch',
                'Cos',
                'Sms',
                'pdf',
                'Excel',
                'MinIO',
                'JustAuth',
                'Pay',
                'Flowable',
                'RabbitMQ',
                'Nacos',
                'Sentinel',
                'Gateway',
                'Sleuth',
                'Seata',
                'Netty',
                'redisson',
                'coupon',
                'order',
                'skill',
                'comment',
                'Signin',
                'JavaAI'
            ],
            '/flutter/': [
                '',
                'start',
                'dart',
                'middle'
            ],
            '/devops/': [
                '',
                'git',
                'maven',
                'linux',
                'linuxNote',
                'docker',
                'nginx',
                'redis',
                'GitLab'
            ],
            '/interview/': [
                '',
                'Java',
                'Collection',
                'HashMap',
                'ConcurrentHashMap',
                'JVM',
                'Thread',
                'AQS',
                'MySQL',
                'MySQL18',
                'Redis',
                'Spring',
                'Mybatis',
                'MQ',
                'interview1',
                'interview2',
                'interview3',
                'interview4',
                'interview5',
                'interview6',
                'interview7',
                'interview8',
                'interview9',
                'interview10'
            ]
        }
    }
}